# Projects 

Materials and outlines for the Final Project for COGS108.

Carefully read through all the details you'll need to know for your COGS108 Final Project [here](https://github.com/COGS108/Projects/blob/master/FinalProject_Guidelines.pdf)

## Project Schedule

#### Project Proposal
Due Sunday, April 21st @ 11:59 pm (Week 3)

#### Final Project
Due Wednesday, June 12th @ 11:59 pm (Finals Week)  

## Project Templates

* [Proposal](https://docs.google.com/document/d/1_M0Zajd00s9r8RNFTWruqngJm0NTHawOqCMWib9C9ys/edit?usp=sharing)
* [Final Project](https://github.com/COGS108/Projects/blob/master/FinalProject.ipynb)
