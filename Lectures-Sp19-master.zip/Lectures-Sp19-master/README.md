# Lectures-Sp19
Slides and Notebooks used in Lecture for Sp19 COGS108 
